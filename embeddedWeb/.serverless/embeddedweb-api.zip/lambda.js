import serverless from "serverless-http";
import express from "express";
import cors from "cors";
import fetch from "node-fetch";
import dotenv from "dotenv";

// Load environment variables
dotenv.config();

const app = express();

// Enable CORS for all routes
app.use(cors());
app.use(express.json());

// API Routes only (static files will be served from S3)
// GET token endpoint with username/email
app.get("/api/token", async (req, res) => {
  try {
    const { username } = req.query;

    if (!username) {
      return res.status(400).json({ error: "Username is required" });
    }

    const API_KEY = process.env.API_KEY;

    // Use GET method for the AWS API endpoint
    const url = new URL(
      "https://t4b67cht52.execute-api.us-east-1.amazonaws.com/dev/tokens"
    );
    url.searchParams.append("userName", username);

    const response = await fetch(url.toString(), {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": API_KEY,
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(
        `HTTP error! status: ${response.status}, body: ${errorText}`
      );
    }

    const data = await response.json();
    res.json(data);
  } catch (error) {
    console.error("Token creation failed:", error);
    res.status(500).json({ error: error.message });
  }
});

// Health check endpoint
app.get("/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Export the serverless handler
export const handler = serverless(app);

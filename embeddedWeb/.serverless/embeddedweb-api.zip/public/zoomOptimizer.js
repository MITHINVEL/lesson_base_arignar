class ZoomDetector {
  constructor() {
    this.currentZoom = 100;
    this.callbacks = [];
    this.init();
  }

  init() {
    this.detectZoom();
    this.setupListeners();
  }

  detectZoom() {
    // Method 1: Device pixel ratio (most reliable)
    const dprZoom = Math.round(window.devicePixelRatio * 100);

    // Method 2: Screen vs window comparison
    const screenZoom =
      screen.width && window.outerWidth
        ? Math.round((screen.width / window.outerWidth) * 100)
        : 100;

    // Method 3: Visual viewport (modern browsers)
    const visualZoom = window.visualViewport
      ? Math.round((window.innerWidth / window.visualViewport.width) * 100)
      : 100;

    // Use the most reliable method
    let detectedZoom = dprZoom;

    // Fallback logic for better accuracy
    if (
      Math.abs(screenZoom - 100) < Math.abs(dprZoom - 100) &&
      screenZoom > 0
    ) {
      detectedZoom = screenZoom;
    }

    // Common zoom levels validation
    const commonZooms = [
      50, 67, 75, 80, 90, 100, 110, 125, 150, 175, 200, 250, 300,
    ];
    const closest = commonZooms.reduce((prev, curr) =>
      Math.abs(curr - detectedZoom) < Math.abs(prev - detectedZoom)
        ? curr
        : prev
    );

    const oldZoom = this.currentZoom;
    this.currentZoom = closest;

    if (oldZoom !== this.currentZoom) {
      this.callbacks.forEach((callback) => callback(this.currentZoom, oldZoom));
    }

    return {
      zoom: this.currentZoom,
      dprZoom,
      screenZoom,
      visualZoom,
      devicePixelRatio: window.devicePixelRatio,
      isZoomed: this.currentZoom !== 100,
    };
  }

  setupListeners() {
    let resizeTimeout;

    // Listen for zoom changes via resize
    window.addEventListener("resize", () => {
      clearTimeout(resizeTimeout);
      resizeTimeout = setTimeout(() => this.detectZoom(), 150);
    });

    // Visual viewport listener (modern browsers)
    if (window.visualViewport) {
      window.visualViewport.addEventListener("resize", () => {
        this.detectZoom();
      });
    }

    // Media query listeners for common zoom levels
    const zoomQueries = [
      { zoom: 125, query: "(-webkit-min-device-pixel-ratio: 1.25)" },
      { zoom: 150, query: "(-webkit-min-device-pixel-ratio: 1.5)" },
      { zoom: 175, query: "(-webkit-min-device-pixel-ratio: 1.75)" },
      { zoom: 200, query: "(-webkit-min-device-pixel-ratio: 2)" },
    ];

    zoomQueries.forEach(({ zoom, query }) => {
      const mediaQuery = window.matchMedia(`screen and ${query}`);
      mediaQuery.addEventListener("change", () => {
        setTimeout(() => this.detectZoom(), 100);
      });
    });
  }

  onZoom(callback) {
    this.callbacks.push(callback);
  }

  getZoomLevel() {
    return this.currentZoom;
  }

  isZoomed() {
    return this.currentZoom !== 100;
  }

  getZoomInfo() {
    return this.detectZoom();
  }
}

class IframeZoomOptimizer {
  constructor(iframeSelector = "#flutterFrame") {
    this.iframe = document.querySelector(iframeSelector);
    this.contentArea = document.querySelector(".content-area");
    this.baseWidth = 720;
    this.baseHeight = 600;

    if (!this.iframe || !this.contentArea) {
      console.warn("IframeZoomOptimizer: Required elements not found");
      return;
    }

    this.zoomDetector = new ZoomDetector();
    this.zoomDetector.onZoom((newZoom, oldZoom) => {
      this.adjustForZoom(newZoom);
      console.log(`Zoom changed: ${oldZoom}% → ${newZoom}%`);
    });

    // Initial adjustment
    this.adjustForZoom(this.zoomDetector.getZoomLevel());

    // Create zoom indicator
    this.createZoomIndicator();
  }

  adjustForZoom(zoomLevel) {
    const zoomFactor = zoomLevel / 100;

    // Remove existing zoom classes
    document.body.className = document.body.className.replace(/zoom-\d+/g, "");

    // Add new zoom class
    if (zoomLevel !== 100) {
      document.body.classList.add(`zoom-${zoomLevel}`);
    }

    // Calculate optimal dimensions based on available space and zoom
    const availableWidth = this.contentArea.clientWidth - 40; // Account for padding
    const optimalWidth = Math.min(this.baseWidth / zoomFactor, availableWidth);
    const optimalHeight = this.baseHeight / zoomFactor;

    // Apply CSS custom properties for dynamic adjustment
    document.documentElement.style.setProperty("--zoom-factor", zoomFactor);
    document.documentElement.style.setProperty(
      "--optimal-width",
      `${optimalWidth}px`
    );
    document.documentElement.style.setProperty(
      "--optimal-height",
      `${optimalHeight}px`
    );

    // Update zoom indicator
    this.updateZoomIndicator(zoomLevel, optimalWidth, optimalHeight);

    // Dispatch custom event for other components
    this.iframe.dispatchEvent(
      new CustomEvent("zoomAdjusted", {
        detail: { zoomLevel, width: optimalWidth, height: optimalHeight },
      })
    );
  }

  createZoomIndicator() {
    // Remove existing indicator
    const existing = document.querySelector(".zoom-indicator");
    if (existing) existing.remove();

    const indicator = document.createElement("div");
    indicator.className = "zoom-indicator";
    indicator.innerHTML = `
      <div style="
        position: absolute;
        top: 10px;
        right: 10px;
        background: rgba(0, 0, 0, 0.8);
        color: white;
        padding: 8px 12px;
        border-radius: 4px;
        font-size: 12px;
        z-index: 1001;
        font-family: monospace;
        pointer-events: none;
        transition: opacity 0.3s ease;
      ">
        <div id="zoom-level">100%</div>
        <div id="iframe-size" style="font-size: 10px; opacity: 0.8;">720×600</div>
      </div>
    `;

    this.contentArea.appendChild(indicator);

    // Auto-hide after 5 seconds, show on zoom change
    this.hideIndicatorTimeout = setTimeout(() => {
      indicator.style.opacity = "0.3";
    }, 5000);
  }

  updateZoomIndicator(zoomLevel, width, height) {
    const levelEl = document.getElementById("zoom-level");
    const sizeEl = document.getElementById("iframe-size");
    const indicator = document.querySelector(".zoom-indicator");

    if (levelEl && sizeEl && indicator) {
      levelEl.textContent = `${zoomLevel}%`;
      sizeEl.textContent = `${Math.round(width)}×${Math.round(height)}`;

      // Show indicator briefly on change
      indicator.style.opacity = "1";
      clearTimeout(this.hideIndicatorTimeout);
      this.hideIndicatorTimeout = setTimeout(() => {
        indicator.style.opacity = "0.3";
      }, 3000);

      // Color coding for zoom levels
      const color =
        zoomLevel === 100
          ? "#4caf50"
          : zoomLevel <= 150
          ? "#ff9800"
          : "#f44336";
      indicator.querySelector("div").style.background = `rgba(${
        zoomLevel === 100
          ? "76, 175, 80"
          : zoomLevel <= 150
          ? "255, 152, 0"
          : "244, 67, 54"
      }, 0.9)`;
    }
  }

  getOptimalDimensions(zoomLevel = null) {
    const zoom = zoomLevel || this.zoomDetector.getZoomLevel();
    const factor = zoom / 100;
    const availableWidth = this.contentArea.clientWidth - 40;

    return {
      width: Math.min(this.baseWidth / factor, availableWidth),
      height: this.baseHeight / factor,
      zoomLevel: zoom,
      factor: factor,
    };
  }

  // Method to manually trigger zoom detection (useful for testing)
  refreshZoom() {
    const zoomInfo = this.zoomDetector.detectZoom();
    this.adjustForZoom(zoomInfo.zoom);
    return zoomInfo;
  }
}

// Global debug functions
window.debugZoom = function () {
  const detector = new ZoomDetector();
  const info = detector.getZoomInfo();
  console.table(info);
  return info;
};

window.simulateZoom = function (level) {
  document.body.className = document.body.className.replace(/zoom-\d+/g, "");
  document.body.classList.add(`zoom-${level}`);
  document.documentElement.style.setProperty("--zoom-factor", level / 100);
  console.log(`Simulating ${level}% zoom`);
};
